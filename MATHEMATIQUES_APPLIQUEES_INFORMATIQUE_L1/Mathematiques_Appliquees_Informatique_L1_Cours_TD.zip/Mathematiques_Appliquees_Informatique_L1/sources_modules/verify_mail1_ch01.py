#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Vérification arithmétique du chapitre 1 — MAI Licence 1 (Task ID : maiL1-ch1).

Recalcule TOUTES les valeurs numériques annoncées dans
mai_l1/docs/cours_l1/20_ch01.tex : conversions dans les deux sens,
additions/multiplications/soustractions/divisions binaires et hexadécimales,
méthode de Horner, puissances de 2, préfixes kilo/méga/giga/téra,
tailles en Ko/Go, table ASCII, complément à 2.

Chaque contrôle affiche PASS ou FAIL ; le script sort avec 0 uniquement
si tous les contrôles passent.
"""

import sys

_failures = []
_total = 0


def check(nom, condition):
    """Affiche PASS/FAIL pour un contrôle et mémorise les échecs."""
    global _total
    _total += 1
    if condition:
        print("[PASS] " + nom)
    else:
        _failures.append(nom)
        print("[FAIL] " + nom)


def to_base(n, b):
    """Écriture de l'entier n en base b (2 à 16), par divisions successives."""
    chiffres = "0123456789ABCDEF"
    if n == 0:
        return "0"
    s = ""
    while n > 0:
        n, r = divmod(n, b)
        s = chiffres[r] + s
    return s


def vals(s, base):
    """Valeurs des chiffres (symboles) d'une écriture en base <= 16."""
    return [int(c, base) for c in s]


def bin_add(a, b):
    """Addition binaire posée, colonne par colonne avec reports."""
    i, j, carry, out = len(a) - 1, len(b) - 1, 0, ""
    while i >= 0 or j >= 0 or carry:
        s = carry
        if i >= 0:
            s += int(a[i])
            i -= 1
        if j >= 0:
            s += int(b[j])
            j -= 1
        out = str(s % 2) + out
        carry = s // 2
    return out


def bin_sub(a, b):
    """Soustraction binaire posée, colonne par colonne avec emprunts."""
    haut = [int(c) for c in a]
    bas = [int(c) for c in b.zfill(len(a))]
    out = []
    for i in range(len(haut) - 1, -1, -1):
        d = haut[i] - bas[i]
        if d < 0:
            d += 2
            k = i - 1
            while haut[k] == 0:
                haut[k] = 1  # la colonne prêteuse à 0 reçoit l'emprunt
                k -= 1
            haut[k] -= 1
        out.append(str(d))
    return "".join(reversed(out))


def complement1(s):
    return "".join("1" if c == "0" else "0" for c in s)


# ============================================================
print("== Section 1.1 : base et symboles d'un systeme de numeration ==")
# ============================================================
check("1.1 (19017)10 : tous les chiffres < 10", all(d < 10 for d in vals("19017", 10)))
check("1.1 (1011101)2 : tous les chiffres < 2", all(d < 2 for d in vals("1011101", 2)))
check("1.1 (1370)8 : tous les chiffres < 8", all(d < 8 for d in vals("1370", 8)))
check("1.1 (A9120)16 : tous les chiffres < 16", all(d < 16 for d in vals("A9120", 16)))
check("1.1 (18095)8 : ECRITURE INVALIDE (contient les chiffres 8 et 9 >= base)",
      any(d >= 8 for d in vals("18095", 16)) and {8, 9} <= set(vals("18095", 16)))
check("1.1 (A9120)16 : A vaut 10", int("A", 16) == 10)
check("1.1 hexa : A=10, B=11, C=12, D=13, E=14, F=15",
      [int(c, 16) for c in "ABCDEF"] == [10, 11, 12, 13, 14, 15])
check("1.1 valeurs de controle : (1011101)2=93, (1370)8=760, (A9120)16=692512",
      int("1011101", 2) == 93 and int("1370", 8) == 760 and int("A9120", 16) == 692512)

# ============================================================
print("== Section 1.2 : vers le decimal (numerotation de position) ==")
# ============================================================
check("1.2 (1023)4 = 1x64 + 0x16 + 2x4 + 3 = 75",
      1 * 4**3 + 0 * 4**2 + 2 * 4**1 + 3 * 4**0 == 75 and int("1023", 4) == 75)
check("1.2 (10111001)2 : poids [128,0,32,16,8,0,0,1], somme 185",
      [1 * 2**7, 0 * 2**6, 1 * 2**5, 1 * 2**4, 1 * 2**3, 0 * 2**2, 0 * 2**1, 1 * 2**0]
      == [128, 0, 32, 16, 8, 0, 0, 1]
      and int("10111001", 2) == 185)
check("1.2 128 + 32 + 16 + 8 + 1 = 185", 128 + 32 + 16 + 8 + 1 == 185)
check("1.2 (175)8 = 1x64 + 7x8 + 5 = 125 (64, et non 164)",
      1 * 8**2 + 7 * 8**1 + 5 * 8**0 == 125 and int("175", 8) == 125)
check("1.2 (A24)16 = 10x256 + 2x16 + 4 = 2596",
      10 * 16**2 + 2 * 16**1 + 4 * 16**0 == 2596 and int("A24", 16) == 2596)
check("1.2 Horner (1101)2 = (((1x2)+1)x2+0)x2+1 = 13",
      (((1 * 2) + 1) * 2 + 0) * 2 + 1 == 13 and int("1101", 2) == 13)
check("1.2 Horner (123)8 = (((1x8)+2)x8)+3 = 83",
      (((1 * 8) + 2) * 8) + 3 == 83 and int("123", 8) == 83)
check("1.2 poids binaires 2^7=128, 2^3=8, 8^2=64, 16^2=256",
      2**7 == 128 and 2**3 == 8 and 8**2 == 64 and 16**2 == 256)

# ============================================================
print("== Section 1.3 : du decimal vers la base b (divisions successives) ==")
# ============================================================
check("1.3 35 -> (100011)2 par divisions successives", to_base(35, 2) == "100011")
check("1.3 verification (100011)2 = 32 + 2 + 1 = 35", int("100011", 2) == 35)
check("1.3 125 -> (175)8 par divisions successives", to_base(125, 8) == "175")
check("1.3 2596 -> (A24)16 (le reste 10 s'ecrit A)", to_base(2596, 16) == "A24")
check("1.3 lecture a l'envers des restes de 35 : 110001 = 49 et non 35",
      int("110001", 2) == 49 and 49 != 35)
check("1.3 coherences avec la section 1.2 : (175)8=125 et (A24)16=2596",
      int("175", 8) == 125 and int("A24", 16) == 2596)

# ============================================================
print("== Section 1.4 : raccourcis binaire-octal et binaire-hexadecimal ==")
# ============================================================
check("1.4 table octale : 0-7 sur 3 bits",
      all(format(d, "03b") == s for d, s in
          {0: "000", 1: "001", 2: "010", 3: "011", 4: "100", 5: "101", 6: "110", 7: "111"}.items()))
check("1.4 table hexa : 0-F sur 4 bits (A->1010, F->1111)",
      format(10, "04b") == "1010" and format(15, "04b") == "1111"
      and all(int(format(d, "04b"), 2) == d for d in range(16)))
check("1.4 (175)8 -> 001 111 101 -> 1111101 par substitution 3 bits",
      "".join(format(int(c), "03b") for c in "175") == "001111101"
      and "001111101".lstrip("0") == "1111101")
check("1.4 (1111101)2 -> (175)8 par regroupement 3 bits depuis la droite",
      to_base(int("1111101", 2), 8) == "175")
check("1.4 voie longue : (175)8 = 125 = (1111101)2",
      int("175", 8) == 125 == int("1111101", 2))
check("1.4 (A24)16 -> 1010 0010 0100 par substitution 4 bits",
      "".join(format(int(c, 16), "04b") for c in "A24") == "101000100100")
check("1.4 (101000100100)2 -> (A24)16 par regroupement 4 bits",
      to_base(int("101000100100", 2), 16) == "A24")
check("1.4 (7356)8 -> 111 011 101 110 -> (EEE)16",
      "".join(format(int(c), "03b") for c in "7356") == "111011101110"
      and to_base(int("7356", 8), 16) == "EEE" and int("7356", 8) == int("EEE", 16) == 3822)
check("1.4 (1A2F)16 = 0001 1010 0010 1111 = 6703",
      format(int("1A2F", 16), "016b") == "0001101000101111" and int("1A2F", 16) == 6703)

# ============================================================
print("== Section 1.5 : operations arithmetiques en base quelconque ==")
# ============================================================
check("1.5 (1011)2=11, (1101)2=13, somme 24 = (11000)2",
      int("1011", 2) == 11 and int("1101", 2) == 13
      and 11 + 13 == 24 and format(24, "b") == "11000")
check("1.5 addition binaire posee colonne par colonne : 1011+1101 = 11000",
      bin_add("1011", "1101") == "11000")
check("1.5 reports de l'addition : 1,1,1,1 et retenue finale",
      (1 + 1) // 2 == 1 and (1 + 0 + 1) // 2 == 1 and (0 + 1 + 1) // 2 == 1
      and (1 + 1 + 1) // 2 == 1)
check("1.5 (1011)x(101) : 11x5 = 55 = (110111)2",
      int("1011", 2) * int("101", 2) == 55 and format(55, "b") == "110111")
check("1.5 produits partiels : 1011 + (0000<<1) + (1011<<2) = 110111",
      0b1011 + (0b0000 << 1) + (0b1011 << 2) == 0b110111)
check("1.5 division binaire : (1010)2 / (10)2 = (101)2 soit 10/2 = 5",
      int("1010", 2) // int("10", 2) == int("101", 2)
      and int("1010", 2) % int("10", 2) == 0 and int("101", 2) == 5)
check("1.5 soustraction posee : (1101)-(0110) = (0111)",
      bin_sub("1101", "0110") == "0111")
check("1.5 verification soustraction : 13 - 6 = 7 = (0111)2",
      13 - 6 == 7 and int("0111", 2) == 7)
check("1.5 complement a 1 de 00000100 = 11111011", complement1("00000100") == "11111011")
check("1.5 complement a 2 = complement a 1 + 1 = 11111100",
      bin_add(complement1("00000100"), "1") == "11111100")
check("1.5 (-4) code sur 8 bits : 11111100 + 00000100 = 0 (mod 256), 11111100 = 256-4",
      (int("11111100", 2) + int("00000100", 2)) % 256 == 0
      and int("11111100", 2) == 252 == 256 - 4)
check("1.5 (2A5)16 = 677 et (19E)16 = 414",
      int("2A5", 16) == 677 and int("19E", 16) == 414)
check("1.5 (2A5)+(19E) = (443)16 ; 677+414 = 1091 = 4x256+4x16+3",
      to_base(677 + 414, 16) == "443" and int("443", 16) == 1091 == 4 * 256 + 4 * 16 + 3)
d0, r0 = divmod(5 + 14, 16)
d1, r1 = divmod(10 + 9 + d0, 16)
d2, r2 = divmod(2 + 1 + d1, 16)
check("1.5 colonnes hexa : 5+E -> 3 (report 1) ; A+9+1 -> 4 (report 1) ; 2+1+1 -> 4 ; pas de report final",
      (r0, d0, r1, d1, r2, d2) == (3, 1, 4, 1, 4, 0))

# ============================================================
print("== Section 1.6 : unites d'information et codes ==")
# ============================================================
check("1.6 2^8 = 256, 2^16 = 65536, 2^32 = 4294967296",
      2**8 == 256 and 2**16 == 65536 and 2**32 == 4294967296)
check("1.6 2^7 = 128 (codes ASCII)", 2**7 == 128)
check("1.6 prefixes decimaux : kilo 10^3, mega 10^6, giga 10^9, tera 10^12",
      10**3 == 1000 and 10**6 == 1000000 and 10**9 == 1000000000 and 10**12 == 1000000000000)
check("1.6 equivalents binaires : 2^10=1024, 2^20=1048576, 2^30=1073741824, 2^40=1099511627776",
      2**10 == 1024 and 2**20 == 1048576 and 2**30 == 1073741824 and 2**40 == 1099511627776)
check("1.6 2^10 = 1024 est proche de 10^3 = 1000", 1000 <= 2**10 < 2000)
check("1.6 2^16 = 2^6 x 2^10 = 64 x 1024 = 65536 (env. 64000)",
      2**16 == 2**6 * 2**10 == 64 * 1024 == 65536)
check("1.6 2^24 = 2^4 x 2^10 x 2^10 = 16 x 1024 x 1024 = 16777216 (env. 16 millions)",
      2**24 == 2**4 * 2**10 * 2**10 == 16 * 1024 * 1024 == 16777216)
check("1.6 page de 2500 caracteres : 2500 octets = 2,5 ko ; /1024 = 2,44 Ko",
      2500 / 1000 == 2.5 and round(2500 / 1024, 2) == 2.44)
check("1.6 cle USB 64 Go : 64x10^9 = 64000000000 octets ; 64x2^30 = 68719476736 octets",
      64 * 10**9 == 64000000000 and 64 * 2**30 == 68719476736)
check("1.6 forfait 5 Go : 5x10^9 = 5000000000 octets ; 5x2^30 = 5368709120 octets",
      5 * 10**9 == 5000000000 and 5 * 2**30 == 5368709120)
check("1.6 forfait 5 Go : 5000000000 / 2500 = 2000000 pages de texte",
      5000000000 / 2500 == 2000000.0)
check("1.6 ASCII : A=65, B=66, a=97, 0=48, espace=32",
      ord("A") == 65 and ord("B") == 66 and ord("a") == 97 and ord("0") == 48 and ord(" ") == 32)
check("1.6 binaires ASCII sur 7 bits : 0100000, 0110000, 1000001, 1000010, 1100001",
      format(32, "07b") == "0100000" and format(48, "07b") == "0110000"
      and format(65, "07b") == "1000001" and format(66, "07b") == "1000010"
      and format(97, "07b") == "1100001")
check("1.6 plages ASCII : majuscules 65-90, minuscules 97-122, chiffres 48-57",
      [ord(c) for c in "AZ"] == [65, 90] and [ord(c) for c in "az"] == [97, 122]
      and [ord(c) for c in "09"] == [48, 57])
check("1.6 majuscule + 32 = minuscule (un seul bit change : 65 -> 97)",
      ord("a") - ord("A") == 32 and (65 ^ 32) == 97)
check("1.6 Unicode 16 bits : 2^16 = 65536 codes", 2**16 == 65536)

# ============================================================
print("")
print("Controles executes : %d ; echecs : %d" % (_total, len(_failures)))
if _failures:
    print("CONTROLES EN ECHEC :")
    for f in _failures:
        print("  - " + f)
    sys.exit(1)
print("RESULTAT GLOBAL : 100 %% PASS")
sys.exit(0)
