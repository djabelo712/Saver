# -*- coding: utf-8 -*-
"""Verification de TOUTES les valeurs annoncees au chapitre 2
(« La logique des propositions et l'algebre de Boole ») du cours
Mathematiques Appliquees a l'Informatique, Licence 1, CPTEC.

Controles :
  1. tables de verite des six connecteurs (non, et, ou, ou-exclusif,
     implication, equivalence) dans l'ordre des lignes 11, 10, 01, 00 ;
  2. operations bit a bit sur les mots P = 01100111 et Q = 11110001 ;
  3. tautologie du raisonnement de l'accuse ((C->N) et non N) -> non C,
     sur toutes les combinaisons (itertools.product), plus diagnostic de
     la table a huit lignes du cours source (W traitee comme lettre
     independante) qui ne peut pas etre une tautologie ;
  4. contradiction P et non(P ou Q) et tautologie (P et Q) ou non(P et Q) ;
  5. equivalences fondamentales : P->Q = non P ou Q, non(P->Q) = P et non Q,
     P<->Q = (P->Q) et (Q->P), lois de Morgan, distributivites ;
  6. simplifications booleennes sur les 8 combinaisons :
     (A+B)(A+non B) = A ;  A + non A * non B = A + non B ;
     A * (A + B) = A ; et diagnostic : A + A * non B n'est PAS A + non B ;
  7. table du circuit F = A*B + non B*C avec colonnes intermediaires ;
  8. chiffrement XOR : M, K, C = M xor K, puis C xor K = M ;
  9. tables des portes NON-ET et NON-OU ; propriete du ou exclusif
     a xor a = 0 et a xor 0 = a ; 2^n lignes pour n propositions ;
     motif des colonnes de la table a trois lettres.

Sortie : une ligne PASS/FAIL par controle ; exit 0 si et seulement si
tous les controles passent.
"""

import itertools
import sys

fails = []
NCONTROLES = 0


def check(nom, condition):
    global NCONTROLES
    NCONTROLES += 1
    print(("PASS  " if condition else "FAIL  ") + nom)
    if not condition:
        fails.append(nom)


NOT = lambda a: 1 - a
AND = lambda a, b: a & b
OR = lambda a, b: a | b
XOR = lambda a, b: a ^ b
IMP = lambda a, b: 1 - a * (1 - b)          # non a ou b
EQ = lambda a, b: 1 - (a ^ b)               # equivalence

PARES = [(1, 1), (1, 0), (0, 1), (0, 0)]     # ordre des tables du cours

# 1. Tables des six connecteurs -------------------------------------------
check("table non P = 0,0,1,1 (P=1,1,0,0)",
      [NOT(p) for p, q in PARES] == [0, 0, 1, 1])
check("table P et Q = 1,0,0,0",
      [AND(p, q) for p, q in PARES] == [1, 0, 0, 0])
check("table P ou Q = 1,1,1,0",
      [OR(p, q) for p, q in PARES] == [1, 1, 1, 0])
check("table P oux Q = 0,1,1,0",
      [XOR(p, q) for p, q in PARES] == [0, 1, 1, 0])
check("table P -> Q = 1,0,1,1",
      [IMP(p, q) for p, q in PARES] == [1, 0, 1, 1])
check("table P <-> Q = 1,0,0,1",
      [EQ(p, q) for p, q in PARES] == [1, 0, 0, 1])

# 2. Operations bit a bit sur P et Q --------------------------------------
P = "01100111"
Q = "11110001"
pa = "".join(str(AND(int(a), int(b))) for a, b in zip(P, Q))
po = "".join(str(OR(int(a), int(b))) for a, b in zip(P, Q))
px = "".join(str(XOR(int(a), int(b))) for a, b in zip(P, Q))
check("P et Q  = 01100001", pa == "01100001")
check("P ou Q  = 11110111", po == "11110111")
check("P oux Q = 10010110", px == "10010110")

# 3. Raisonnement de l'accuse ---------------------------------------------
# Formule du cours : ((C -> N) et non N) -> non C  (W remplacee par non N)
accuse = []
for C, N in itertools.product([1, 0], repeat=2):
    accuse.append(IMP(AND(IMP(C, N), NOT(N)), NOT(C)))
check("formule de l'accuse ((C->N) et non N) -> non C : tautologie (4 lignes)",
      all(v == 1 for v in accuse) and len(accuse) == 4)

# Table a huit lignes du cours source : W lettre independante.
# Ligne C=1, N=1, W=1 (etant a New York ET a Washington : combinaison
# impossible) donne 0 : la formule a trois lettres independantes n'est
# donc pas une tautologie, la table du cours source est fausse.
src8 = [IMP(AND(IMP(C, N), W), NOT(C))
        for C, N, W in itertools.product([1, 0], repeat=3)]
check("diagnostic source : ((C->N) et W) -> non C n'est pas une tautologie "
      "(0 sur la ligne C=N=W=1)", src8[0] == 0)
check("diagnostic source : le dernier 0 imprime (C=N=W=0) devrait etre 1",
      IMP(AND(IMP(0, 0), 0), NOT(0)) == 1)

# 4. Contradiction et tautologie du support ESGAE -------------------------
contra = [AND(p, NOT(OR(p, q))) for p, q in PARES]
tauto = [OR(AND(p, q), NOT(AND(p, q))) for p, q in PARES]
check("P et non(P ou Q) : contradiction (colonnes toutes nulles)",
      contra == [0, 0, 0, 0])
check("(P et Q) ou non(P et Q) : tautologie (colonnes toutes a 1)",
      tauto == [1, 1, 1, 1])

# 5. Equivalences fondamentales -------------------------------------------
check("P -> Q equivalent a non P ou Q (4 lignes)",
      all(IMP(p, q) == OR(NOT(p), q) for p, q in PARES))
check("non(P -> Q) equivalent a P et non Q (4 lignes)",
      all(NOT(IMP(p, q)) == AND(p, NOT(q)) for p, q in PARES))
check("P <-> Q equivalent a (P->Q) et (Q->P) (4 lignes)",
      all(EQ(p, q) == AND(IMP(p, q), IMP(q, p)) for p, q in PARES))
check("loi de Morgan : non(P ou Q) = non P et non Q",
      all(NOT(OR(p, q)) == AND(NOT(p), NOT(q)) for p, q in PARES))
check("loi de Morgan : non(P et Q) = non P ou non Q",
      all(NOT(AND(p, q)) == OR(NOT(p), NOT(q)) for p, q in PARES))
dist1 = all(AND(p, OR(q, r)) == OR(AND(p, q), AND(p, r))
            for p, q, r in itertools.product([1, 0], repeat=3))
dist2 = all(OR(p, AND(q, r)) == AND(OR(p, q), OR(p, r))
            for p, q, r in itertools.product([1, 0], repeat=3))
check("distributivite de et sur ou (8 combinaisons)", dist1)
check("distributivite de ou sur et (8 combinaisons)", dist2)
check("piege : non(P->Q) different de non P -> non Q "
      "(colonnes [0,1,0,0] contre [1,1,0,1])",
      [NOT(IMP(p, q)) for p, q in PARES] == [0, 1, 0, 0]
      and [IMP(NOT(p), NOT(q)) for p, q in PARES] == [1, 1, 0, 1])
check("contraposee : P->Q equivalent a non Q -> non P (4 lignes)",
      all(IMP(p, q) == IMP(NOT(q), NOT(p)) for p, q in PARES))

# 6. Simplifications booleennes (8 combinaisons) --------------------------
ok1 = ok2 = ok3 = okdiag = True
for A, B in itertools.product([0, 1], repeat=2):
    Bb = NOT(B)
    if AND(OR(A, B), OR(A, Bb)) != A:
        ok1 = False
    if OR(A, AND(NOT(A), Bb)) != OR(A, Bb):
        ok2 = False
    if AND(A, OR(A, B)) != A:
        ok3 = False
    if OR(A, AND(A, Bb)) != OR(A, Bb):   # valeur annoncee faussement
        okdiag = False
check("(A + B)(A + non B) = A (8 combinaisons)", ok1)
check("A + non A * non B = A + non B (8 combinaisons)", ok2)
check("A * (A + B) = A (8 combinaisons)", ok3)
check("diagnostic : A + A * non B = A sur toutes les combinaisons",
      all(OR(A, AND(A, NOT(B))) == A
          for A, B in itertools.product([0, 1], repeat=2)))
check("diagnostic : A + A * non B n'est PAS A + non B "
      "(dissociation sur A=0, B=0)",
      OR(0, AND(0, NOT(0))) != OR(0, NOT(0)))

# 7. Circuit F = A*B + non B*C --------------------------------------------
circuit = []
for A, B, C in itertools.product([1, 0], repeat=3):
    Bb, AB, BbC = NOT(B), AND(A, B), AND(NOT(B), C)
    F = OR(AB, BbC)
    circuit.append((A, B, C, Bb, AB, BbC, F))
attendu = [
    (1, 1, 1, 0, 1, 0, 1),
    (1, 1, 0, 0, 1, 0, 1),
    (1, 0, 1, 1, 0, 1, 1),
    (1, 0, 0, 1, 0, 0, 0),
    (0, 1, 1, 0, 0, 0, 0),
    (0, 1, 0, 0, 0, 0, 0),
    (0, 0, 1, 1, 0, 1, 1),
    (0, 0, 0, 1, 0, 0, 0),
]
check("table complete du circuit F = A*B + non B*C (8 lignes, "
      "colonnes B non, A*B, non B*C, F)", circuit == attendu)
check("F lu dans l'ordre ABC = 000..111 vaut 01000111",
      "".join(str(r[6]) for r in reversed(circuit)) == "01000111")

# 8. Chiffrement par ou exclusif (support ESGAE) --------------------------
M = "1011010011110001"
K = "1010111001001110"
C = "".join(str(XOR(int(a), int(b))) for a, b in zip(M, K))
M2 = "".join(str(XOR(int(a), int(b))) for a, b in zip(C, K))
check("C = M oux K = 0001 1010 1011 1111", C == "0001101010111111")
check("C oux K redonne M", M2 == M)
check("propriete a oux a = 0 et a oux 0 = a",
      all(XOR(a, a) == 0 and XOR(a, 0) == a
          for a in (0, 1)))

# 9. Portes NON-ET, NON-OU ; 2^n lignes ; table a trois lettres -----------
ORDRE = [(0, 0), (0, 1), (1, 0), (1, 1)]     # ordre des portes : AB = 00,01,10,11
check("table ET   (AB = 00,01,10,11) = 0,0,0,1",
      [AND(p, q) for p, q in ORDRE] == [0, 0, 0, 1])
check("table OU   (AB = 00,01,10,11) = 0,1,1,1",
      [OR(p, q) for p, q in ORDRE] == [0, 1, 1, 1])
check("table OUX  (AB = 00,01,10,11) = 0,1,1,0",
      [XOR(p, q) for p, q in ORDRE] == [0, 1, 1, 0])
nand = [NOT(AND(p, q)) for p, q in ORDRE]
nor = [NOT(OR(p, q)) for p, q in ORDRE]
check("table NON-ET = 1,1,1,0", nand == [1, 1, 1, 0])
check("table NON-OU = 1,0,0,0", nor == [1, 0, 0, 0])
check("2^n lignes : n = 2, 3, 4 donnent 4, 8, 16",
      [len(list(itertools.product([0, 1], repeat=n))) for n in (2, 3, 4)]
      == [4, 8, 16])
check("table a trois lettres : P=11110000, Q=11001100, R=10101010",
      ["".join(str(t[i]) for t in
               itertools.product([1, 0], repeat=3)) for i in (0, 1, 2)]
      == ["11110000", "11001100", "10101010"])

print()
if fails:
    print("ECHEC : %d controle(s) en echec" % len(fails))
    sys.exit(1)
print("SUCCES : les %d controles passent" % NCONTROLES)
sys.exit(0)
