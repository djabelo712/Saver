# -*- coding: utf-8 -*-
"""Verification arithmetique du chapitre 3 « Les evenements et les probabilites »
   (MAI Licence 1, Institut Superieur CPTEC) — Task ID : maiL1-ch3.

Recalcule TOUTES les probabilites et comptages annonces dans
mai_l1/docs/cours_l1/22_ch03.tex. Affiche PASS/FAIL pour chaque controle
et sort avec le code 0 seulement si tout passe.
"""
import sys
from itertools import product
from fractions import Fraction
from math import comb, factorial

echecs = []
controles = 0


def check(nom, condition, detail=""):
    global controles
    controles += 1
    ok = bool(condition)
    print("[%s] %s%s" % ("PASS" if ok else "FAIL", nom, ("  -> " + detail) if detail else ""))
    if not ok:
        echecs.append(nom)


# ============================================================
# Section 3.1 — Univers
# ============================================================
deux_des = list(product(range(1, 7), repeat=2))
check("S3.1 : |Omega| deux des = 36", len(deux_des) == 36)
check("S3.1 : 2^3 = 8 issues pour trois pieces", 2 ** 3 == 8)
check("S3.1 : 2^4 = 16 issues pour quatre pieces", 2 ** 4 == 16)

# ============================================================
# Section 3.2 — Somme paire (corrigee : 18 issues) et somme 7
# ============================================================
A_paire = [c for c in deux_des if (c[0] + c[1]) % 2 == 0]
A_attendu = [(1, 1), (1, 3), (1, 5), (2, 2), (2, 4), (2, 6), (3, 1), (3, 3), (3, 5),
             (4, 2), (4, 4), (4, 6), (5, 1), (5, 3), (5, 5), (6, 2), (6, 4), (6, 6)]
check("S3.2 : |A somme paire| = 18", len(A_paire) == 18, "recalcule = %d" % len(A_paire))
check("S3.2 : liste de A exactement celle imprimee", sorted(A_paire) == sorted(A_attendu))
check("S3.2 : 9 couples de deux impairs + 9 de deux pairs = 18",
      len([c for c in deux_des if c[0] % 2 == 1 and c[1] % 2 == 1])
      + len([c for c in deux_des if c[0] % 2 == 0 and c[1] % 2 == 0]) == 18)

B_sept = [c for c in deux_des if c[0] + c[1] == 7]
B_attendu = [(1, 6), (2, 5), (3, 4), (4, 3), (5, 2), (6, 1)]
check("S3.2 : |B somme 7| = 6", len(B_sept) == 6)
check("S3.2 : liste de B exactement celle imprimee", sorted(B_sept) == sorted(B_attendu))
check("S3.2 : A et B incompatibles (intersection vide)",
      set(A_paire).isdisjoint(B_sept))
check("S3.2 : |A u B| = 18 + 6 - 0 = 24",
      len(set(A_paire) | set(B_sept)) == 24)
check("S3.2 : |contraire de A| = 36 - 18 = 18",
      len(deux_des) - len(A_paire) == 18)
check("S3.2 : B inclus dans le contraire de A (7 impaire)",
      set(B_sept).issubset({c for c in deux_des if (c[0] + c[1]) % 2 == 1}))

# ============================================================
# Section 3.3 — Denombrement
# ============================================================
check("S3.3 : deux des 6 x 6 = 36", 6 * 6 == 36)
check("S3.3 : code a quatre chiffres 10^4 = 10 000", 10 ** 4 == 10000)
check("S3.3 : plaque 26^3 = 17 576", 26 ** 3 == 17576)
check("S3.3 : plaque 26^3 x 10^3 = 17 576 000", 26 ** 3 * 10 ** 3 == 17576000)

A_8_3 = factorial(8) // factorial(5)
check("S3.3 : A_8^3 = 8!/5! = 336", A_8_3 == 336)
check("S3.3 : A_8^3 = 8 x 7 x 6 = 336", 8 * 7 * 6 == 336)
check("S3.3 : A_5^2 = 5 x 4 = 20", factorial(5) // factorial(3) == 20)

check("S3.3 : C(5,2) = 10", comb(5, 2) == 10)
check("S3.3 : C(49,6) = 13 983 816", comb(49, 6) == 13983816)
check("S3.3 : C(49,6) via produit/720 = 13 983 816",
      (49 * 48 * 47 * 46 * 45 * 44) // 720 == 13983816
      and (49 * 48 * 47 * 46 * 45 * 44) % 720 == 0)
check("S3.3 : symetrie C(49,6) = C(49,43)", comb(49, 6) == comb(49, 43))
check("S3.3 : rarete : 1/13 983 816 = env. 7 chances sur 100 millions",
      7.0 <= 1e8 / 13983816 <= 8.0, "1e8/13983816 = %.2f" % (1e8 / 13983816))
check("S3.3 : cent grilles par tirage : 13 983 816 / 100 = env. 139 838 tirages",
      139800 <= 13983816 / 100 < 140000, "%.2f" % (13983816 / 100))

# ============================================================
# Section 3.4 — Cas equiprobable
# ============================================================
trois_pieces = [''.join(t) for t in product('PF', repeat=3)]
check("S3.4 : |Omega| trois pieces = 8", len(trois_pieces) == 8)
A_une_pile = [s for s in trois_pieces if s.count('P') == 1]
check("S3.4 : A = {PFF, FPF, FFP} (exactement une pile)",
      sorted(A_une_pile) == sorted(['PFF', 'FPF', 'FFP']))
p_3_8 = Fraction(3, 8)
check("S3.4 : P(une pile, deux faces) = 3/8 = 0,375 = 37,5 %",
      p_3_8 == Fraction(3, 8) and float(p_3_8) == 0.375 and float(p_3_8) * 100 == 37.5)

check("S3.4 : P(impair au de) = 3/6 = 1/2 = 50 %",
      Fraction(3, 6) == Fraction(1, 2) and float(Fraction(3, 6)) == 0.5)
p_sept = Fraction(len(B_sept), len(deux_des))
check("S3.4 : P(somme 7) = 6/36 = 1/6",
      p_sept == Fraction(1, 6))
check("S3.4 : P(somme 7) arrondi 0,167 = 16,7 %",
      round(float(p_sept), 3) == 0.167 and round(float(p_sept) * 100, 1) == 16.7)
check("S3.4 : somme 7 somme la plus probable (6 couples, aucun autre n'atteint 6)",
      max(sum(1 for c in deux_des if c[0] + c[1] == s) for s in range(2, 13)) == 6)

p_pique = Fraction(13, 52)
check("S3.4 : P(pique) = 13/52 = 1/4 = 25 %",
      p_pique == Fraction(1, 4) and float(p_pique) == 0.25)
p_pique_ou_roi = Fraction(13 + 4 - 1, 52)
check("S3.4 : P(pique ou roi) = 13/52 + 4/52 - 1/52 = 16/52 = 4/13",
      p_pique_ou_roi == Fraction(16, 52) == Fraction(4, 13))
check("S3.4 : P(pique ou roi) arrondi 0,308 = 30,8 %",
      round(float(p_pique_ou_roi), 3) == 0.308 and round(float(p_pique_ou_roi) * 100, 1) == 30.8)
check("S3.4 : formule reunion coherent avec enumération 52 cartes",
      Fraction(len([1] * 13) + len([1] * 4) - 1, 52) == Fraction(16, 52))

# ============================================================
# Section 3.5 — Conditionnelle, composees, totale
# ============================================================
p_2_sachant_pair = Fraction(1, 6) / Fraction(3, 6)
check("S3.5 : P(2 | pair) = (1/6)/(3/6) = 1/3",
      p_2_sachant_pair == Fraction(1, 3))
check("S3.5 : P(2 | pair) arrondi 33,3 %",
      round(float(p_2_sachant_pair) * 100, 1) == 33.3)

p_deux_blanches = Fraction(5, 8) * Fraction(4, 7)
check("S3.5 : urne 5B/3R sans remise : 5/8 x 4/7 = 20/56 = 5/14",
      p_deux_blanches == Fraction(20, 56) == Fraction(5, 14))
check("S3.5 : P(deux blanches) arrondi 0,357 = 35,7 %",
      round(float(p_deux_blanches), 3) == 0.357 and round(float(p_deux_blanches) * 100, 1) == 35.7)

p_totale = Fraction(6, 10) * Fraction(9, 10) + Fraction(4, 10) * Fraction(8, 10)
check("S3.5 : proba totale CPTEC = 0,6 x 0,9 + 0,4 x 0,8 = 0,86",
      p_totale == Fraction(43, 50) and float(p_totale) == 0.86)
check("S3.5 : feuilles de l'arbre 0,54 + 0,06 + 0,32 + 0,08 = 1",
      abs((0.6 * 0.9) + (0.6 * 0.1) + (0.4 * 0.8) + (0.4 * 0.2) - 1.0) < 1e-12)
check("S3.5 : feuilles reussite 0,54 + 0,32 = 0,86",
      abs((0.6 * 0.9) + (0.4 * 0.8) - 0.86) < 1e-12)

# ============================================================
# Section 3.6 — Independance
# ============================================================
# De + piece : independance par produit et par enumeration
p_pair = Fraction(3, 6)
p_pile = Fraction(1, 2)
couples_dp = list(product(range(1, 7), ['P', 'F']))
fav = [c for c in couples_dp if c[0] % 2 == 0 and c[1] == 'P']
check("S3.6 : |Omega| de + piece = 12", len(couples_dp) == 12)
check("S3.6 : P(pair et pile) par enumeration = 3/12 = 1/4",
      Fraction(len(fav), len(couples_dp)) == Fraction(1, 4))
check("S3.6 : P(pair) x P(pile) = 1/2 x 1/2 = 1/4 = P(pair et pile)",
      p_pair * p_pile == Fraction(len(fav), len(couples_dp)) == Fraction(1, 4))

# Quatre pieces
quatre_pieces = [''.join(t) for t in product('PF', repeat=4)]
check("S3.6 : |Omega| quatre pieces = 16", len(quatre_pieces) == 16)
a3 = [s for s in quatre_pieces if s.count('P') == 3]
b2 = [s for s in quatre_pieces if s.count('P') == 2]
check("S3.6 : C(4,3) = 4 suites a trois piles", comb(4, 3) == 4 and len(a3) == 4)
check("S3.6 : P(trois piles, une face) = 4/16 = 1/4 = 25 %",
      Fraction(len(a3), 16) == Fraction(1, 4) and float(Fraction(len(a3), 16)) == 0.25)
check("S3.6 : C(4,2) = 6 suites a deux piles", comb(4, 2) == 6 and len(b2) == 6)
check("S3.6 : P(deux piles, deux faces) = 6/16 = 3/8 = 37,5 %",
      Fraction(len(b2), 16) == Fraction(3, 8) and float(Fraction(len(b2), 16)) == 0.375)
check("S3.6 : les cinq répartitions (1+4+6+4+1)/16 somment a 1",
      sum(comb(4, k) for k in range(5)) == 16
      and sum(Fraction(comb(4, k), 16) for k in range(5)) == 1)

# Incompatibles non independants (impair / pair au de)
p_impair_inter_pair = Fraction(0, 1)
p_impair_fois_pair = Fraction(3, 6) * Fraction(3, 6)
check("S3.6 : impair et pair : P(A n B) = 0 alors que P(A) x P(B) = 1/4 != 0",
      p_impair_inter_pair == 0 and p_impair_fois_pair == Fraction(1, 4))

# ============================================================
# Bilan
# ============================================================
print("")
print("Bilan : %d controles, %d PASS, %d FAIL" % (controles, controles - len(echecs), len(echecs)))
if echecs:
    print("Controles en echec :")
    for nom in echecs:
        print("  - " + nom)
    sys.exit(1)
print("Tous les controles du chapitre 3 sont exacts.")
sys.exit(0)
