# -*- coding: utf-8 -*-
"""Verification arithmetique complete des TD 1, 2, 3 (MAI Licence 1).
Recalcule TOUTES les conversions, tables de verite et probabilites annoncees.
0 ecart tolere : chaque controle doit afficher PASS.
"""
import itertools
import sys

FAILS = []

def check(name, cond):
    if cond:
        print(f"PASS  {name}")
    else:
        print(f"FAIL  {name}")
        FAILS.append(name)

# ============================ TD 1 : NUMERATION ============================
# Exercice 1
check("TD1/1 (110101)_2 = 53", int('110101', 2) == 53)
check("TD1/1 bits de 53 : 32+16+4+1", 32 + 16 + 4 + 1 == 53 and bin(53)[2:] == '110101')
check("TD1/1 (127,4)_8 = 87,5", 1*64 + 2*8 + 7 + 4/8 == 87.5)
check("TD1/1 (2E,8)_16 = 46,5", 2*16 + 14 + 8/16 == 46.5)

# Exercice 2
check("TD1/2 2026 -> binaire 11111101010", bin(2026)[2:] == '11111101010')
check("TD1/2 controle 2026 : 1024+512+256+128+64+32+8+2", 1024+512+256+128+64+32+8+2 == 2026)
check("TD1/2 2026 -> octal 3752", oct(2026)[2:] == '3752')
check("TD1/2 2026 -> hexa 7EA", hex(2026)[2:].upper() == '7EA')
check("TD1/2 divisions base 2 de 2026", 
      [(2026//2**k) % 2 for k in range(11)][::-1] == [int(c) for c in '11111101010'])
check("TD1/2 77 -> binaire 1001101", bin(77)[2:] == '1001101')
check("TD1/2 77 = 64+8+4+1", 64 + 8 + 4 + 1 == 77)
# divisions successives telles qu'affichees dans le corrige (2026 en base 2)
q, rs, n = 2026, [], 2026
while n > 0:
    rs.append(n % 2); n //= 2
check("TD1/2 chaines de restes 2026 base 2", ''.join(str(d) for d in rs[::-1]) == '11111101010')

# Exercice 3
check("TD1/3 (175)_8 -> 1111101", bin(int('175', 8))[2:] == '1111101' and int('175', 8) == 125)
check("TD1/3 125 = 64+32+16+8+4+1", 64+32+16+8+4+1 == 125)
check("TD1/3 (A24)_16 -> 101000100100", bin(int('A24', 16))[2:] == '101000100100' and int('A24', 16) == 2596)
check("TD1/3 2596 = 2048+512+32+4", 2048 + 512 + 32 + 4 == 2596)
check("TD1/3 1111101101_2 = 1005", int('1111101101', 2) == 1005)
check("TD1/3 1005 = 512+256+128+64+32+8+4+1", 512+256+128+64+32+8+4+1 == 1005)
check("TD1/3 1005 -> octal 1755", oct(1005)[2:] == '1755')
check("TD1/3 1005 -> hexa 3ED", hex(1005)[2:].upper() == '3ED')
check("TD1/3 1755_8 = 3ED_16 = 1005", int('1755', 8) == 1005 == int('3ED', 16))

# Exercice 4
check("TD1/4 11110111_2 = 247", int('11110111', 2) == 247)
check("TD1/4 11111_2 = 31", int('11111', 2) == 31)
check("TD1/4 101011_2 = 43", int('101011', 2) == 43)
check("TD1/4 247+31 = 278 = 100010110_2", 247 + 31 == 278 and bin(278)[2:] == '100010110')
check("TD1/4 278-43 = 235 = 11101011_2", 278 - 43 == 235 and bin(235)[2:] == '11101011')
check("TD1/4 235 = 128+64+32+8+2+1", 128+64+32+8+2+1 == 235)
check("TD1/4 278 = 256+16+4+2", 256+16+4+2 == 278)
# addition posee : retenues colonne par colonne (les 8 retenues sortantes valent 1)
a, b = [int(c) for c in '11110111'], [int(c) for c in '00011111']
carry, digits = 0, []
for x, y in zip(a[::-1], b[::-1]):
    s = x + y + carry
    digits.append(s % 2); carry = s // 2
digits.append(carry)
check("TD1/4 addition posee = 100010110", ''.join(map(str, digits[::-1])) == '100010110')
# soustraction posee avec emprunt : 100010110 - 000101011
A = [int(c) for c in '100010110']; B = [int(c) for c in '000101011']
res, brw = [], 0
for x, y in zip(A[::-1], B[::-1]):
    d = x - y - brw
    if d < 0:
        d += 2; brw = 1
    else:
        brw = 0
    res.append(d)
check("TD1/4 soustraction posee = 011101011", ''.join(map(str, res[::-1])) == '011101011')
check("TD1/4 3A7_16 = 935 ; 19B_16 = 411", int('3A7', 16) == 935 and int('19B', 16) == 411)
check("TD1/4 935+411 = 1346 = 542_16", 935 + 411 == 1346 and hex(1346)[2:].upper() == '542')
check("TD1/4 542_16 = 5x256+4x16+2", 5*256 + 4*16 + 2 == 1346)

# Exercice 5
check("TD1/5 2^8 = 256", 2**8 == 256)
check("TD1/5 2^24 = 16777216", 2**24 == 16_777_216)
check("TD1/5 4 Go = 4e9 octets ; 4 Gio = 4x2^30 = 4294967296", 
      4*10**9 == 4_000_000_000 and 4*2**30 == 4_294_967_296)
check("TD1/5 ecart = 294967296", 4*2**30 - 4*10**9 == 294_967_296)
check("TD1/5 ASCII C = 67 -> 01000011", ord('C') == 67 and format(67, '08b') == '01000011')
check("TD1/5 67 = 64+2+1", 64 + 2 + 1 == 67)
check("TD1/5 ASCII T = 84 -> 01010100", ord('T') == 84 and format(84, '08b') == '01010100')
check("TD1/5 84 = 64+16+4", 64 + 16 + 4 == 84)

# Exercice 6
check("TD1/6 64 Go = 64e9 octets", 64 * 10**9 == 64_000_000_000)
check("TD1/6 2^30 = 1073741824", 2**30 == 1_073_741_824)
check("TD1/6 64e9 / 2^30 = 59,60...", abs(64*10**9 / 2**30 - 59.6046) < 0.001)
check("TD1/6 arrondi 59,6 Gio", round(64*10**9 / 2**30, 1) == 59.6)
check("TD1/6 ecart percu 64 - 59,6 = 4,4 Gio", round(64 - 64*10**9/2**30, 1) == 4.4)
check("TD1/6 10^3 = 1000 codes", 10**3 == 1000)
check("TD1/6 2^9 = 512 < 1000 <= 1024 = 2^10", 2**9 == 512 < 1000 <= 1024 == 2**10)
check("TD1/6 (2C)_16 = 44 = 101100_2", int('2C', 16) == 44 and bin(44)[2:] == '101100')
check("TD1/6 44 = 32+8+4", 32 + 8 + 4 == 44)
check("TD1/6 substitution : 0010 1100 = 101100", bin(int('2C',16))[2:] == '101100')

# ============================ TD 2 : LOGIQUE ============================
V, F = True, False
valuations2 = [(F,F), (F,V), (V,F), (V,V)]

def tt(f):
    return ['V' if f(p, q) else 'F' for p, q in valuations2]

# Exercice 2
check("TD2/2 ¬P∧Q = F V F F", tt(lambda p,q: (not p) and q) == ['F','V','F','F'])
check("TD2/2 P∨¬Q = V F V V", tt(lambda p,q: p or (not q)) == ['V','F','V','V'])
check("TD2/2 ¬(P∧Q) = V V V F", tt(lambda p,q: not (p and q)) == ['V','V','V','F'])
check("TD2/2 ¬P∨¬Q = V V V F", tt(lambda p,q: (not p) or (not q)) == ['V','V','V','F'])
check("TD2/2 De Morgan : ¬(P∧Q) ≡ ¬P∨¬Q", tt(lambda p,q: not (p and q)) == tt(lambda p,q: (not p) or (not q)))

# Exercice 3
check("TD2/3 ¬(P∨Q) = V F F F", tt(lambda p,q: not (p or q)) == ['V','F','F','F'])
check("TD2/3 ¬P∧¬Q = V F F F", tt(lambda p,q: (not p) and (not q)) == ['V','F','F','F'])
check("TD2/3 De Morgan 2 : ¬(P∨Q) ≡ ¬P∧¬Q", tt(lambda p,q: not (p or q)) == tt(lambda p,q: (not p) and (not q)))
check("TD2/3 P⇒Q = V V F V", tt(lambda p,q: (not p) or q) == ['V','V','F','V'])
check("TD2/3 ¬P∨Q = V V F V", tt(lambda p,q: (not p) or q) == ['V','V','F','V'])
check("TD2/3 ¬(P⇒Q) = F F V F", tt(lambda p,q: p and (not q)) == ['F','F','V','F'])
check("TD2/3 P∧¬Q = F F V F", tt(lambda p,q: p and (not q)) == ['F','F','V','F'])
check("TD2/3 réciproque Q⇒P = V F V V", tt(lambda p,q: (not q) or p) == ['V','F','V','V'])
check("TD2/3 contraposée ¬Q⇒¬P = V V F V", tt(lambda p,q: q or (not p)) == ['V','V','F','V'])
check("TD2/3 contraposée ≡ P⇒Q ; réciproque ≠ P⇒Q",
      tt(lambda p,q: q or (not p)) == tt(lambda p,q: (not p) or q)
      and tt(lambda p,q: (not q) or p) != tt(lambda p,q: (not p) or q))

# Exercice 4 : simplifications booléennes sur 8 valuations
valuations3 = list(itertools.product([F,V], repeat=3))
def allval(f):
    return [f(*v) for v in valuations3]
X  = allval(lambda a,b,c: (a and b) or (a and (b or c)))
Xs = allval(lambda a,b,c: a and (b or c))
Xs2= allval(lambda a,b,c: (a and b) or (a and c))
Y  = allval(lambda a,b,c: (a or b) and (a or c))
Ys = allval(lambda a,b,c: a or (b and c))
Z  = allval(lambda a,b,c: a and (a or b))
Zs = allval(lambda a,b,c: a)
check("TD2/4 X = A·B + A·(B+C) ≡ A·(B+C)", X == Xs)
check("TD2/4 A·(B+C) ≡ A·B + A·C", Xs == Xs2)
check("TD2/4 Y = (A+B)(A+C) ≡ A+B·C", Y == Ys)
check("TD2/4 Z = A·(A+B) ≡ A", Z == Zs)
check("TD2/4 colonne Y : F F F V V V V V", ['V' if v else 'F' for v in Y] == ['F','F','F','V','V','V','V','V'])
check("TD2/4 colonne X : F F F F F V V V", ['V' if v else 'F' for v in X] == ['F','F','F','F','F','V','V','V'])

# Exercice 5 : opérations bit à bit
P, Q = 0b01100111, 0b11110001
check("TD2/5 P∧Q = 01100001", format(P & Q, '08b') == '01100001')
check("TD2/5 P∨Q = 11110111", format(P | Q, '08b') == '11110111')
check("TD2/5 P⊕Q = 10010110", format(P ^ Q, '08b') == '10010110')
M, K = 0b1011, 0b0110
C = M ^ K
check("TD2/5 C = M⊕K = 1101", format(C, '04b') == '1101')
check("TD2/5 C⊕K = 1011 = M", format(C ^ K, '04b') == '1011' and (C ^ K) == M)
check("TD2/5 a⊕a = 0 ; a⊕0 = a", (M ^ M) == 0 and (M ^ 0) == M)
check("TD2/5 (A∧B)∨(¬A∧B) ≡ B", 
      allval(lambda a,b,c: (a and b) or ((not a) and b)) == allval(lambda a,b,c: b))

# ============================ TD 3 : PROBABILITES ============================
from fractions import Fraction as Fr

# Exercice 1
Omega = set(range(1, 7))
A = {2, 4, 6}; B = {4, 5, 6}
check("TD3/1 A = {2,4,6} ; B = {4,5,6}", A == {2,4,6} and B == {4,5,6})
check("TD3/1 A∩B = {4,6} ; A∪B = {2,4,5,6} ; Ā = {1,3,5}",
      A & B == {4,6} and (A | B) == {2,4,5,6} and (Omega - A) == {1,3,5})
check("TD3/1 P(A)=P(B)=P(Ā)=1/2 ; P(A∩B)=1/3 ; P(A∪B)=2/3",
      Fr(len(A),6) == Fr(1,2) and Fr(len(B),6) == Fr(1,2) and Fr(len(A&B),6) == Fr(1,3)
      and Fr(len(A|B),6) == Fr(2,3) and Fr(len(Omega-A),6) == Fr(1,2))
check("TD3/1 1/2+1/2-1/3 = 2/3", Fr(1,2)+Fr(1,2)-Fr(1,3) == Fr(2,3))

# Exercice 2 : deux dés
pairs = [(i, j) for i in range(1, 7) for j in range(1, 7)]
check("TD3/2 |Ω| = 36", len(pairs) == 36)
S = [(i,j) for (i,j) in pairs if i+j == 7]
check("TD3/2 S = {(1,6),(2,5),(3,4),(4,3),(5,2),(6,1)}", set(S) == {(1,6),(2,5),(3,4),(4,3),(5,2),(6,1)})
check("TD3/2 P(S) = 6/36 = 1/6", Fr(len(S),36) == Fr(1,6))
Pev = [(i,j) for (i,j) in pairs if (i+j) % 2 == 0]
check("TD3/2 liste des 18 sommes paires (corrige)",
      set(Pev) == {(1,1),(1,3),(1,5),(3,1),(3,3),(3,5),(5,1),(5,3),(5,5),
                   (2,2),(2,4),(2,6),(4,2),(4,4),(4,6),(6,2),(6,4),(6,6)})
check("TD3/2 |P| = 18 et P(P) = 1/2", len(Pev) == 18 and Fr(18,36) == Fr(1,2))
check("TD3/2 somme paire <=> meme parite : 3x3+3x3 = 18", 3*3 + 3*3 == 18)
G = [(i,j) for (i,j) in pairs if i+j >= 10]
check("TD3/2 G = {(4,6),(5,5),(5,6),(6,4),(6,5),(6,6)}", set(G) == {(4,6),(5,5),(5,6),(6,4),(6,5),(6,6)})
check("TD3/2 P(G) = 1/6", Fr(len(G),36) == Fr(1,6))
check("TD3/2 S∩P = vide (7 impair)", set(S) & set(Pev) == set())

# Exercice 3 : urne 75 boules
check("TD3/3 10+30+20+15 = 75", 10+30+20+15 == 75)
check("TD3/3 P(O∪R) = 25/75 = 1/3 ≈ 0,333", Fr(15+10,75) == Fr(1,3) and round(float(Fr(1,3)), 3) == 0.333)
check("TD3/3 P(L∪O) = 35/75 = 7/15 ≈ 0,467", Fr(20+15,75) == Fr(7,15) and round(float(Fr(7,15)), 3) == 0.467)
check("TD3/3 P(¬L) = 55/75 = 11/15 ≈ 0,733", Fr(75-20,75) == Fr(11,15) and round(float(Fr(11,15)), 3) == 0.733)
check("TD3/3 P(R∪B∪L) = 60/75 = 4/5 = 0,8", Fr(10+30+20,75) == Fr(4,5))
check("TD3/3 somme des 4 réponses = 35/15 > 1", Fr(1,3)+Fr(7,15)+Fr(11,15)+Fr(4,5) == Fr(35,15))
check("TD3/3 somme des 4 couleurs = 1", Fr(10,75)+Fr(30,75)+Fr(20,75)+Fr(15,75) == 1)
check("TD3/3 1-20/75 = 11/15 (complémentaire)", 1 - Fr(20,75) == Fr(11,15))

# Exercice 4 : agence mobile money
t_f, t_nf, nt_f, nt_nf = 25, 35, 10, 30
check("TD3/4 marges : 25+35=60 ; 25+10=35 ; 35+30=65 ; 60+40=100",
      t_f+t_nf == 60 and t_f+nt_f == 35 and t_nf+nt_nf == 65 and 60+40 == 100)
check("TD3/4 total tableau = 100", t_f+t_nf+nt_f+nt_nf == 100)
check("TD3/4 P(T) = 0,6 ; P(F) = 0,35", Fr(60,100) == Fr(3,5) and abs(float(Fr(3,5)) - 0.6) < 1e-12 and Fr(35,100) == Fr(7,20) and abs(float(Fr(7,20)) - 0.35) < 1e-12)
check("TD3/4 P(T|F) = 25/35 = 5/7 ≈ 0,714", Fr(25,35) == Fr(5,7) and round(float(Fr(5,7)), 3) == 0.714)
check("TD3/4 P(F|T) = 25/60 = 5/12 ≈ 0,417", Fr(25,60) == Fr(5,12) and round(float(Fr(5,12)), 3) == 0.417)
check("TD3/4 P(T∪F) = 0,6+0,35-0,25 = 0,7", abs(0.6 + 0.35 - 0.25 - 0.7) < 1e-12 and Fr(70,100) == Fr(7,10))
check("TD3/4 71,4% et 41,7% (pourcentages du corrige)",
      round(float(Fr(5,7))*100, 1) == 71.4 and round(float(Fr(5,12))*100, 1) == 41.7)

# Exercice 5 : atelier de Kara
pD = 0.6*0.02 + 0.4*0.05
check("TD3/5 P(D) = 0,012+0,020 = 0,032",
      Fr(6,10)*Fr(2,100) == Fr(12,1000) and Fr(4,10)*Fr(5,100) == Fr(20,1000)
      and Fr(12,1000)+Fr(20,1000) == Fr(32,1000) == Fr(4,125)
      and abs(pD - 0.032) < 1e-12)
check("TD3/5 P(A|D) = 0,012/0,032 = 0,375", (0.6*0.02)/pD == 0.375)
check("TD3/5 P(B|D) = 62,5%", round((0.4*0.05)/pD*100, 1) == 62.5)
check("TD3/5 P(D1∩D2) = 0,032² = 0,001024", 0.032*0.032 == 0.001024)
check("TD3/5 1/0,001024 ≈ 977", round(1/0.001024) == 977)
check("TD3/5 3,2% (lecture du corrige)", round(pD*100, 1) == 3.2)
check("TD3/5 37,5% (lecture du corrige)", round((0.6*0.02)/pD*100, 1) == 37.5)

# ============================ BILAN ============================
print()
if FAILS:
    print(f"{len(FAILS)} ECHEC(S) :", FAILS)
    sys.exit(1)
total = 0
print("TOUS LES CONTROLES SONT PASSÉS.")
